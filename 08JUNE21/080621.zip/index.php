<?php
$m=60;
/*if($m>50){
	echo "P";
}else{
	echo "F";
}*/
echo ($m>50)?"P":"N";
?>