<?php include('top.php')?>

<h1>About</h1>

<?php include('footer.php')?>