<img src="https://chart.apis.google.com/chart?cht=qr&chs=400x400&chl=https://programmingwithvishal.com/demo/qr1/index.php?link=https://google.com&chco=60DA22"/>
