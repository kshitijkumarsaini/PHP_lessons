<?php
$lang['btn']="Login";
?>