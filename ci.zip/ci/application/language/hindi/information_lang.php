<?php
$lang['btn']="लॉग इन करें";
?>