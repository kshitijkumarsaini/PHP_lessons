<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Website extends CI_Model {
	function getMyQuery(){
		$sql="select * from pages";
		$query=$this->db->query($sql);
		return $query->result();
	}
	
	function getData(){
		$this->db->select('id');
		$this->db->from('page');
		$this->db->where('id',1);
		$query = $this->db->get();
		$result=$query->result();
		return $result;
	}
	
	function insertData($table,$arr){
		//$this->db->insert($table,$arr);
		$this->db->insert_batch($table,$arr);
	}
	
	function updateData($table,$arr,$where,$value){
		$this->db->where($where,$value);
		$this->db->update($table,$arr);
	}
	
	function deleteData($table,$where,$value){
		$this->db->where($where,$value);
		$this->db->delete($table);
	}
	
	function get_count(){
		return $this->db->count_all('student');
	}
	
	function get_grid($end,$start){
		$this->db->limit($start,$end);
		$query=$this->db->get('student');
		return $query->result();
	}
	
	function get_data(){
		//$this->db->select_sum('marks');
		//$this->db->select_avg('marks');
		//$this->db->select_min('marks');
		//$this->db->select_max('marks');
		//$query=$this->db->get('student');
		/*$this->db->select('city.id,city.city,state.state');
		$this->db->from('city');
		$this->db->join('state','state.id=city.state_id');*/
		$this->db->select('*');
		$this->db->from('city');
		//$this->db->where('city','Agra');
		$this->db->order_by('id','asc');
		$query=$this->db->get();
		return $query->result();
	}
}
