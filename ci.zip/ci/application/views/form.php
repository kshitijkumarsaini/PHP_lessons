
<form method="post" action="submit">
	<table>
		<tr>
			<td>Name</td>
			<td><input type="text" name="name" value="<?php echo set_value('name')?>"/>
			<?php echo form_error('name')?>
			</td>
		</tr>
		<tr>
			<td>Email</td>
			<td><input type="text" name="email" value="<?php echo set_value('email')?>"/>
			<?php echo form_error('email')?>
			</td>
		</tr>
		<tr>
			<td>Mobile</td>
			<td><input type="text" name="mobile" value="<?php echo set_value('mobile')?>" />
			<?php echo form_error('mobile')?>
			</td>
		</tr>
		
		<tr>
			<td></td>
			<td><input type="submit" name="submit"/></td>
		</tr>

	</table>
</form>