<?php 
echo "<pre>";
print_r($data);
?>
<h1>Home</h1>
<p>I m home</p>