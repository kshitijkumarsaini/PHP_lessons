<?php
echo "<pre>";
print_r($this->uri->segments);
?>
<form method="post" action="submit_file" enctype="multipart/form-data">
	<input type="file" name="file"/>
	<input type="submit" name="submit"/>
	<?php
	if(isset($error)){
		echo $error;
	}
	?>
</form>