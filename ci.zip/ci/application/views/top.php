<html>
	<head>
		<title>
		<?php
		if(isset($title)){	
			echo $title;
		}
		?>
		</title>
	</head>
	<body>
		<a href="<?php echo SITE_PATH?>">Home</a>
		<a href="<?php echo SITE_PATH?>about">About</a>
		<a href="<?php echo SITE_PATH?>services">Services</a>
		<a href="<?php echo SITE_PATH?>services/1">Services1</a>
		<a href="<?php echo SITE_PATH?>services/2">Services2</a>
		