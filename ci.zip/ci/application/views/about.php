<h1>About</h1>
<p>I m About</p>

<img src="<?php echo SITE_PATH?>template/images/test.jpg" width="200"/>