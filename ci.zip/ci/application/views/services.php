<h1>Services</h1>
<p>I m Services</p>

<img src="<?php echo SITE_PATH?>template/images/test.jpg" width="200"/>