<table border="1" id="table"></table>
<div id="links"></div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
load_grid(0);
function load_grid(uri_seg){
	jQuery.ajax({
		url:'load_grid/'+uri_seg,
		success:function(result){
			result=jQuery.parseJSON(result);
			var table='<tr id=""><td>Id</td><td>Name</td><td>City</td></tr>'+result.html;
			jQuery('#table').html(table);
			jQuery('#links').html(result.link);
		}
	});
}

jQuery('#links').on('click','a',function(e){
	e.preventDefault();
	var page_no=jQuery(this).attr('data-ci-pagination-page');
	load_grid(page_no)
});
</script>