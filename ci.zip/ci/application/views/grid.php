<table border="1">
	<tr>
		<td>Id</td>
		<td>Name</td>
		<td>City</td>
	</tr>
	<?php foreach($arr as $list){?>
	<tr>
		<td><?php echo $list->id?></td>
		<td><?php echo $list->name?></td>
		<td><?php echo $list->city?></td>
	</tr>
	<?php } ?>
</table>

<?php echo $link?>