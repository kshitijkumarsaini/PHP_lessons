<table>
	<tr>
		<td>ID</td>
		<td>Title</td>
	</tr>
	<?php 
	foreach($data as $list){
		echo "<tr>
			<td>".$list->id."</td>
			<td>".$list->title."</td>
		</tr>";	
	}
	?>
</table>