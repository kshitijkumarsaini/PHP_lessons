<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->helper('common_helper');
		$this->lang->load('information','hindi');
	}
	
	public function index()
	{
		$this->load->model('website');	
		$arr['data']=$this->website->getMyQuery();
		///$arr=json_decode(json_encode($arr),true);
		//$this->load->view('table',$arr);
		echo "<pre>";
		print_r($arr['data']);
	}
	
	public function insert()
	{
		$this->load->model('website');
		$arr=[
			['title'=>'Hello1','desc'=>'Test1'],
			['title'=>'Hello2','desc'=>'Test2']
		];	
		$this->website->insertData('pages',$arr);
	}
	
	public function update()
	{
		$this->load->model('website');
		$arr=['title'=>'Hello1','desc'=>'Test1'];	
		$this->website->updateData('pages',$arr,'id',1);
	}
	
	public function delete()
	{
		$this->load->model('website');
		$this->website->deleteData('pages','id',1);
	}
	

	function test(){
		//test();
		/*$this->load->library('cart');
		$obj=new cart();
		$obj->go();*/
		//echo $lang['btn'];
		
		echo "<pre>";
		print_r($this->lang->line('btn'));
		
	}
	
	function gd_lib(){
		/*$config['image_library'] = 'gd2';
		$config['source_image'] = 'test.jpg';
		$config['create_thumb'] = TRUE;
		$config['width'] = 300;
		$config['height'] = 400;
		$this->load->library('image_lib', $config);
		$this->image_lib->resize();*/
		
		$this->load->library('image_lib');
		$config['source_image'] = 'test.jpg';
		$config['wm_text'] = 'Copyright 2006 - John Doe';
		$config['wm_type'] = 'text';
		$config['wm_font_path'] = 'D:/xampp/htdocs/php_class/260421/ci/font/arial.ttf';
		$config['wm_font_size'] = '16';
		$config['wm_font_color'] = 'ffffff';
		$config['wm_vrt_alignment'] = 'top';
		$config['wm_hor_alignment'] = 'center';
		$config['wm_padding'] = '20';
		$this->image_lib->initialize($config);
		$this->image_lib->watermark();
	}
	
	function cal(){
		$prefs = array (
               'show_next_prev'  => TRUE
             );

		$this->load->library('calendar', $prefs);

		//$this->load->library('calendar');
		//echo $this->calendar->generate();
		$data = array(
               3  => 'http://example.com/news/article/2006/03/',
               7  => 'http://example.com/news/article/2006/07/',
               13 => 'http://example.com/news/article/2006/13/',
               26 => 'http://example.com/news/article/2006/26/'
             );
		echo $this->calendar->generate(2006, 6, $data);

	}
	
}
