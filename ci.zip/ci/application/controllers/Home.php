<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	public function index()
	{
		$arr['title']="Home";
		$this->load->view('top',$arr);
		$indexArr['data']=[
			["Ram","Namit"],
			["Ram1","Namit1"]
		];
		$this->load->view('index',$indexArr);
		$this->load->view('footer');
	}
	
	public function about()
	{
		$arr['title']="About";
		$this->load->view('top');
		$this->load->view('about');
		$this->load->view('footer');
		
	}
	
	public function services()
	{
		$arr['title']="Services";
		$this->load->view('top',$arr);
		$this->load->view('services');
		$this->load->view('footer');
		
	}
}
