<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Form extends CI_Controller {
	public function index()
	{
		$this->load->view('form');
	}
	
	function checkname($x){
		if($x=="Vishal"){
			$this->form_validation->set_message('checkname','Please enter other name');
			return false;
		}else{
			return true;
		}
	}
	
	function submit(){
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('name','Username','min_length[3]|max_length[6]');
		$this->form_validation->set_rules('email','Email','required|is_unique[users.email]');
		$this->form_validation->set_rules('mobile','Mobile','required');
		
		if($this->form_validation->run()==FALSE){
			$this->load->view('form');
		}else{
			echo "Thanks";
		}
	}
	
	function form_file(){
		//$this->load->view('form_file');
		echo rand(111,999);
	}
	
	function submit_file(){
		$arr['upload_path']="upload";	
		$arr['allowed_types']="jpg|jpeg|png";
		$arr['max_size']=10;
		
		$this->load->library('upload',$arr);

		if($this->upload->do_upload('file')){
			$msg="Yes";
		}else{
			$msg=$this->upload->display_errors();
		}
		$result['error']=$msg;
		$this->load->view('form_file',$msg);
			
	}
	
	
	function grid(){
		$this->load->model('website');
		$this->load->library('pagination');
		$pagiArr['total_rows']=$this->website->get_count();
		$pagiArr['per_page']=2;
		$pagiArr['uri_segment']=2;
		$pagiArr['attributes'] = array('class' => 'myclass');
		$pagiArr['base_url']="http://127.0.0.1/php_class/260421/ci/grid";
		$this->pagination->initialize($pagiArr);
		$data['link']=$this->pagination->create_links();
		$page=$this->uri->segment(2);
		if($page==''){
			$page=0;
		}
		$data['arr']=$this->website->get_grid($page,$pagiArr['per_page']);
		
		$this->load->view('grid',$data);
		
	}
	
	
	function ajax_grid(){
		$this->load->view('ajax_grid');
	}
	
	function load_grid($uri_seg=0){
		$this->load->model('website');
		$this->load->library('pagination');
		$pagiArr['total_rows']=$this->website->get_count();
		$pagiArr['per_page']=2;
		$pagiArr['uri_segment']=$uri_seg;
		$pagiArr['base_url']="http://127.0.0.1/php_class/260421/ci/ajax_grid";
		$this->pagination->initialize($pagiArr);
		$data['link']=$this->pagination->create_links();
		$page=$uri_seg;
		$arr=$this->website->get_grid($page,$pagiArr['per_page']);
		$html="";
		foreach($arr as $list){
			$html.="<tr><td>".$list->id."</td><td>".$list->name."</td><td>".$list->city."</td></tr>";
		}
		$data['html']=$html;
		echo  json_encode($data);
	}
	
	function get_data(){
		$this->load->model('website');
		
		$result=$this->website->get_data();
		echo "<pre>";
		print_r($result);
		
	}
}
