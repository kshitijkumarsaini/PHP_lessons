<?php
function test(){
	echo "Test";	
}
?>