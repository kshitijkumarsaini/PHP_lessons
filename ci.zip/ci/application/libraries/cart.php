<?php 
class cart{
	function go(){
		echo "Go";
	}
}
?>