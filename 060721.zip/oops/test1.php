<?php
namespace test1;
class test{
	function hello(){
		echo "Hello1";	
	}	
}
?>