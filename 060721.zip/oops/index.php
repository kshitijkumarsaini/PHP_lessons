<?php
include('test1.php');
include('test2.php');

$obj=new test1\test();
$obj->hello();
?>