<?php
namespace test2;
class test{
	function hello(){
		echo "Hello1";	
	}	
}
?>