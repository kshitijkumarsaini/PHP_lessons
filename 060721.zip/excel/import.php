<?php
$con=mysqli_connect("localhost","root","","260421");
if(isset($_POST['submit'])){
	$file=$_FILES['file']['tmp_name'];
	include('PHPExcel/PHPExcel.php');
	include('PHPExcel/PHPExcel/IOFactory.php');
	
	$obj=PHPExcel_IOFactory::load($file);
	
	foreach($obj->getWorksheetIterator() as $sheet){
		$getHighestRow=$sheet->getHighestRow();
		$j=0;
		for($i=0;$i<=$getHighestRow;$i++){
			if($i>1){
				$arr[$j]['name']=$sheet->getCellByColumnAndRow(0,$i)->getValue();
				$arr[$j]['city']=$sheet->getCellByColumnAndRow(1,$i)->getValue();
				$j++;
			}
		}
	}
	
	echo "<pre>";
	print_r($arr);
	
	
}
?>

<form enctype="multipart/form-data" method="post">
	<input type="file" name="file"/>
	<input type="submit" name="submit"/>
</form>