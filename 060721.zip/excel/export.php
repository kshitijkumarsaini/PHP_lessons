<?php
$con=mysqli_connect("localhost","root","","260421");
include('Excel.php');
$res=mysqli_query($con,"select * from product");
$arr=[];
$i=0;
while($row=mysqli_fetch_assoc($res)){
	$arr[$i]['User Name']=$row['name'];
	$arr[$i]['City']=$row['city'];
	$i++;
}
$obj=new Excel();
$file=date('d-m-Y').".xlsx";
$obj->userDefinedstream($file,$arr);
?>