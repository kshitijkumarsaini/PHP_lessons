<?php
$folder="test";
$files=scandir($folder,1);

echo "<pre>";
print_r($files);
?>