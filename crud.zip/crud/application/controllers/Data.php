<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Data extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('crud_model');
	}

	public function index(){
		$arr['data']=$this->crud_model->get_data('users');
		$data['title']='List All Data';
		$data['description']='Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage.';
		$this->load->view('templates/header',$data);
		$this->load->view('data/index',$arr);
		$this->load->view('templates/footer');
	}

	public function create(){
		$data['title']='Add New Record';
        $data['description']="There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form";

		$this->load->view('templates/header',$data);
		$this->load->view('data/create');
		$this->load->view('templates/footer');
		
	}

	public function update($id = NULL){
		$id=$this->input->get('id');
		$arr['data']=$this->crud_model->get_data('users',$id);

		$data['title']='Update Record';
        $data['description']="There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form";

		$this->load->view('templates/header',$data);
		$this->load->view('data/update',$arr);
		$this->load->view('templates/footer');
	}

	public function submit_records(){
        $data = array(
			'name' =>  $this->input->post('name'),
			'email' =>  $this->input->post('email'),
			'mobile' =>  $this->input->post('mobile'),
			'address' =>  $this->input->post('address'),
			'created_on' =>  date('Y-m-d H:i:s')
		);
		$this->crud_model->add_data('users',$data);
		redirect('data');
	}

	public function update_records(){
		$id=$this->input->post('id');

		$data = array(
			'name' =>  $this->input->post('name'),
			'email' =>  $this->input->post('email'),
			'mobile' =>  $this->input->post('mobile'),
			'address' =>  $this->input->post('address'),
			'updated_on' =>  date('Y-m-d H:i:s')
		);

		$this->crud_model->update_data('users',$data,$id);
		redirect('data');
	}

	public function delete(){
		$id=$this->input->get('id');
		$this->crud_model->delete_data('users',$id);
		redirect('data');
	}
}
