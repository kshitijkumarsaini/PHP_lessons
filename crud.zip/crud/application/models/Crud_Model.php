<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud_Model extends CI_Model {

    public function __construct() {
        $this->load->database();
    }

    public function get_data($table,$id='') {
        if($id==''){
            $query=$this->db->select('*')
                    ->from($table)
                    ->order_by('created_on','DESC')
                    ->get();

            $result=$query->result();
    
            return $result;
        }else{
            $query=$this->db->select('*')
                    ->from($table)
                    ->where('id',$id)
                    ->get();

            $result=$query->row();

            return $result;
        }
    }

    public function add_data($table,$data) {
        $this->db->insert($table,$data);
        // $this->db->insert_batch($table,$data);
    }

    public function update_data($table,$data,$id) {
        $this->db->where('id',$id)
                ->update($table,$data);
    }

    public function delete_data($table,$id){
        $this->db->where('id',$id)
                ->delete($table);
    }
}