<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<header>
    <div class="p-4 p-md-5 mb-4 text-white rounded bg-dark">
        <div class="col-md-12 px-0">
            <h1 class="display-4 fst-italic"><?php echo $title; ?></h1>
            <p class="lead my-3"><?php echo $description; ?></p>
        </div>
    </div>
</header>

<div class="row pb-5">
    <div class="col-md-10 m-auto">
        <div class="card">
            <div class="card-body">
                <div class="error">
                    
                </div>
            
                <?php echo form_open('data/submit_records'); ?>
                    <div class="mb-3">
                        <label for="title" class="form-label">Your Name</label>
                        <input type="text" name="name" class="form-control form-control-sm" />
                    </div>
                    <div class="mb-3">
                        <label for="title" class="form-label">Your Email</label>
                        <input type="text" name="email" class="form-control form-control-sm" />
                    </div>
                    <div class="mb-3">
                        <label for="title" class="form-label">Your Mobile</label>
                        <input type="text" name="mobile" class="form-control form-control-sm" />
                    </div>
                    <div class="mb-3">
                        <label for="text" class="form-label">Address</label>
                        <textarea name="address" rows="5" class="form-control form-control-sm"></textarea>
                    </div>
                    <input type="submit" name="submit" class="btn btn-primary" value="Create Data" />
                    <a href="<?php echo site_url(); ?>" class="btn btn-primary">Back</a>
                </form>
            </div>
        </div>
    </div>
</div>