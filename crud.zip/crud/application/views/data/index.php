<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// echo "<pre>";
// print_r($data);
// die();
?>

<header>
    <div class="p-4 p-md-5 mb-4 text-white rounded bg-dark">
        <div class="col-md-12 px-0">
            <h1 class="display-4 fst-italic"><?php echo $title; ?></h1>
            <p class="lead my-3"><?php echo $description; ?></p>
        </div>
    </div>
</header>

<div class="py-3 text-center"><a class="btn btn-primary btn-sm" href="<?php echo site_url('data/create'); ?>">Add New Record</a></div>

<main class="container py-5 pt-0">
    <table class="table table-striped table-bordered">
        <thead>
            <tr>
            <th scope="col">ID</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Mobile</th>
            <th scope="col">Address</th>
            <th scope="col">Created On</th>
            <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $count=1;
                foreach($data as $list) { ?>
                    <tr>
                        <td><?php echo $count++; ?></td>
                        <td><?php echo $list->name; ?></td>
                        <td><?php echo $list->email; ?></td>
                        <td><?php echo $list->mobile; ?></td>
                        <td><?php echo $list->address; ?></td>
                        <td><?php echo date('M-d-Y',strtotime($list->created_on)); ?></td>
                        <td>
                            <a href="<?php echo site_url('data/update?id='.$list->id); ?>">Edit</a>
                            <a href="<?php echo site_url('data/delete?id='.$list->id); ?>">Delete</a>
                        </td>
                    </tr>
                <?php
                }
            ?>
        </tbody>
    </table>
</main>