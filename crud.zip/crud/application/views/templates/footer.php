        <footer>
                <div class="container text-center">
                    <p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
                    <p><em>&copy; FWT <?php echo date('Y'); ?>.</em></p>
                </div>
            </footer>
        </main>
        
        <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
    </body>
</html>