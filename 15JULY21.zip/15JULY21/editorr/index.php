<script src="ckeditor/ckeditor.js"></script>
<script src="ckfinder/ckfinder.js"></script>

<form method="post">
    <textarea id="editor" name="editor"></textarea>
    <input type="submit" name="submit">
</form>

<script>
var editor=CKEDITOR.replace('editor');
CKFinder.setupCKEditor( editor );
</script>