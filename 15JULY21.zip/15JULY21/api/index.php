<?php
header('Content-Type: application/json');
if(isset($_GET['url'])){
	$apiTable=[
		"users"=>"users"
	];
	$apiMethod=["create","get","delete","put"];
	$url=$_GET['url'];
	$urlArr=explode("/",$url);
	if(isset($urlArr[0]) && isset($apiTable[$urlArr[0]])){
		$api=$urlArr[0];
		if(isset($urlArr[1]) && in_array($urlArr[1],$apiMethod)){
			if($urlArr[1]=="create" && $_SERVER['REQUEST_METHOD']=='POST'){
				echo "data insert";
			}
		}
	}else{
		echo "not_api";
	}
}
?>