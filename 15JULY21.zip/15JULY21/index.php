<?php
$arr=json_encode(["name"=>"Amit"]);
$ch=curl_init();
curl_setopt($ch,CURLOPT_URL,"http://127.0.0.1/php_class/260421/150721/api/users/create");
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POST,1);
curl_setopt($ch,CURLOPT_CUSTOMREQUEST,'DELETE');
curl_setopt($ch,CURLOPT_POSTFIELDS,$arr);
$result=curl_exec($ch);
curl_close($ch);
echo "<pre>";
print_r($result);
?>